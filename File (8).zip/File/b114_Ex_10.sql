use b114;

show tables;
### Supports csv files and json files
select * from movie_sales;

-- Exercise - 6
SELECT 
    m.title, m1.Domestic_sales, m1.International_sales
FROM
    movies m
        INNER JOIN
    movie_sales m1 ON m.Id = m1.Movie_id;

SELECT 
    m.title, m1.Domestic_sales, m1.International_sales
FROM
    movies m
        INNER JOIN
    movie_sales m1 ON m.Id = m1.Movie_id
where International_sales > Domestic_sales;

SELECT 
    m.title, m1.Rating
FROM
    movies m
        INNER JOIN
    movie_sales m1 ON m.Id = m1.Movie_id
    order by Rating Desc;
    
-- Exercise - 7
select distinct Building from employee;
select * from building_capacity;

select distinct b1.Building_name, emp.Role from 
building_capacity b1
left join employee emp
on b1.Building_name = emp.Building;

-- Exercise - 8
select name, role  from employee_building
where Building is Null;

select distinct b1.building_name from 
building_capacity b1 left join
employee_building empb
on b1.building_name = empb.building where name is Null;

-- Exercise - 9
SELECT 
    m.title,
    ((m1.Domestic_sales + m1.International_sales) / 1000000) AS 
    Combined_Sales_millions
FROM
    movies m
        INNER JOIN
    movie_sales m1 ON m.Id = m1.Movie_Id; 
    
SELECT 
    m.title,
    (m1.Rating*10) AS Percent_Rating
FROM
    movies m
        INNER JOIN
    movie_sales m1 ON m.Id = m1.Movie_Id; 
    
select title, year from movies where year %2 = 0;

-- select * from movies;
create temporary table temp (  
select director, sum(Length_minutes) as Total_minutes
from movies group by director);

use b114;
select * from temp;  #### Created for temporary sessions only

##### View - Virtual Table
create view grp_view as (  
select director, sum(Length_minutes) as Total_minutes
from movies group by director);

select * from grp_view;

-- Exercise - 10
select max(Years_employed) as Longest_Time from employee;
select role, avg(Years_employed) from employee group by role;
select Building, sum(Years_employed) from employee group by Building;

-- Exercise - 11
select role , count(*) as Number_of_Artists from employee where role = "Artist"
group by role;

select role , count(*) as Count from employee group by role;

-- Total Numbers of Years employed by all engineers
select role , sum(Years_employed) as Total from 
employee group by role having role = "Engineer";



    
    




    
